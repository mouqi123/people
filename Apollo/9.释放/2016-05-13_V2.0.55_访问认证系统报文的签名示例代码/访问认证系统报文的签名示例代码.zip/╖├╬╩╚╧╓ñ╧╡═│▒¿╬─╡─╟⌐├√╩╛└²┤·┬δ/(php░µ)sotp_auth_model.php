<?php
/*
 * @class		认证系统接口
 * @function	函数名称
 * @access		访问类型
 * @param		  参数类型
 * @return		返回值
 */
class Sotp_auth_model extends Model {
	
	function __construct()
	{
		parent::Model();
	}
	
	function __destruct()
	{

	}	
	
//---------------------------------------------------------------------------------------------------------	 
	
	/*
	 * @function	申请插件  
	 * 参数：
	 *       $sotp:  app端 sdk接口返回的值  
	 */
	function apply_plugin_new($phone, $sotp, $cjson )
	{
		
		$info = array();
		
		$info['status'] = 0;
		$info['data'] = '{"url":"no"}';
		$info['errorMsg'] = "";
		
		//解析出APP请求参数中的appId
    $appID= $this->getRequestAppid($sotp);
      
    //根据 appId 找到 appkey (web处理，数据库或文件中)
		//todo...
		$appkey = "b9044c9e99c61b094262e9fe43c439b7860f0e6b";
		
		//生成请求认证系统GET参数报文
		$reqmsg = $this->genRequestSotpAuthMsg($sotp, $appkey);
		
		//访问 SOTP认证系统
		$json = $this->reqhttpauth($reqmsg);
			
		//echo $json;
		//echo $this->getResponseAppid($json);
		
		//验证认证系统响应报文的合法性 	
		$ret = $this->verifyResponseValid($json, $appkey);
		
		if ($ret == true) {
			echo "ResponseMsg ok";	
		} else {
			echo "ResponseMsg error";
		}
			
		// 处理返回结果 (web)	
			
		$json_Array=json_decode($json, true);  
			
		if ($json_Array != null) {
			
			$info['status'] = $json_Array['status'];
				
			if ($info['status'] == 0) {   // 执行成功
					$info['data'] = $json_Array['message'];
				} else { 
					$info['errorMsg'] = $ms['errorMsg'];
				}
 			} else {
 				$info['status'] = -1;
 				$info['errorMsg'] = "connect sotpAuth error";
 			}

		  return $info;
	}
 
/*   
 *--------------------------------------------------------------------------------------------
 *  连接SOTP认证系统
 *--------------------------------------------------------------------------------------------
 */
 
//访问认证系统	
	function reqhttpauth($data)
	{
 		
    $ip = "123.56.4.215";
    $port = 8080;          
			
 		 //创建socket连接
    $fp = fsockopen($ip, $port, $errno, $errstr, 3);

		 if (!$fp) {
		 		$ret = '{"type":1, "status":100, "message":{"data":"", "errorMsg":"connect sotpAuth error: '.$url.'"}}';
				return $ret;
		 }
     $pdata = str_replace(" ","%20", "/sotpAuth/portal?".$data);		
   
     $header  = "GET ".$pdata;
     $header .= " HTTP/1.0\r\n";
     $header .= "Host:192.168.1.191\r\n";
     $header .= "\r\n";

     $info = "";
    
    //发送数据
    fputs($fp, $header);
    $inheader = 1;
    
    //接收数据
    while (!feof($fp)) {
        $line = fgets($fp,1024); //去除请求包的头只显示页面的返回数据
        if ($inheader && ($line == "\n" || $line == "\r\n")) {
             $inheader = 0;
        }
        if ($inheader == 0) {
          $info .= $line;
        }
    }

		fclose($fp);
    return substr($info, 2);
	}
	
//***********************************************************************
//*************************调用认证系统 示例代码***********************************	
//***********************************************************************	

	/*
	 * 作用： 获取app端请求报文的AppId 
	 * 接口名称： getRequestAppid  
	 * 接口参数： 
	 *    参数：sdkrequest 示例：key1=v1&key2=v2... (SDK接口返回值)
	 *    返回值： string 示例 AppId, 错误 空值
	 */
	 function getRequestAppid($sdkrequest)
	 {
	 		$arr = array();
	 		
	 		$arr = explode("&", $sdkrequest);	
	 		for($i=0; $i< count($arr); $i++) {
	 			$tmp = explode("=", $arr[$i]);
	 			if ($tmp[0] == "appId")
	 				return $tmp[1];				
	 		}
	 	
	 		return "";
	 }
	
	/*
	 * 作用： 生成请求SOTP认证系统的GET参数报文
   * 接口名称： genRequestSotpAuthMsg 
 	 * 接口参数： 
 	 *     参数： sdkrequest 示例： key1=v1&key2=v2 
 	 *           appKey 
 	 *     返回值： string   示例     RequestSotpAuthMsg
	 */
	 	function genRequestSotpAuthMsg($sdkrequest, $appkey)
		{	 
		 	// 生成随机数
			$arr=range(1,10);
			shuffle($arr);
			foreach($arr as $values)
			{
  			$nonce_str .= $values;
			}
			
			// 生成签名值
			$sotpdata .= $sdkrequest."&nonce_str=".$nonce_str;
			$sign = $this->gensign_val($sotpdata, $appkey);

			// 生成请求SOTP认证系统的GET参数报文
			$res = $sdkrequest."&nonce_str=".$nonce_str."&sign=".$sign;
			
			return $res;
	 	}
	 	
	 /* 
	 	*  作用： 获取认证系统响应报文的AppId
	 	*  接口名称： getResponseAppid 
	 	*  接口参数： 
	 	*       参数：response 认证系统响应报文 示例： {"appId":"e89aa9227b2a2d5","nonce_str":"796","sign":"a58ac3f7","status":0 ,"message":{"errorMsg":""},"serverTime":"2016/04/15 22:04:25"} 
	 	*       返回值：string 示例 AppId
	  */
		function getResponseAppid($response) 
		{
 			$appId = "";
 			$json_Array=json_decode($response, true);  
			
			if ($json_Array != null) {
				$appId = $json_Array['appId'];
 			}
 			
 			return $appId;
		}
		
		/*
	 	 * 作用： 验证认证系统响应报文的合法性 
	   * 接口名称： verifyResponseValid  
	   * 接口参数：
	   *    参数：authResponse 示例：{"appId":"e89aa9227b2a2d5","nonce_str":"796","sign":"a58ac3f7","status":0,"message":{"errorMsg":""},"serverTime":"2016/04/15 22:04:25"}
	   *    返回值： Boolean    true 合法 或  false
	   */
			function verifyResponseValid($authResponse, $appkey)
			{
				$str = "";				
				$json_Array=json_decode($authResponse, true);  
				
				foreach ($json_Array as $key => $val) {
					if(is_array($val)) {
						$tmp = $key."=".json_encode($val)."&";
					} else {
						$tmp = $key."=".$val."&";
					}
    			
    			$str .= $tmp;
	 			}
	 			
	 			$str = substr($str, 0, -1);
	 			$sign = $this->gensign_val($str, $appkey); 
	 			
	 			if ($sign == $json_Array['sign'])
	 				return true;
	 			else
	 				return false;
			}
		
	 	/*
	 	 *  生成sign值
	 	 */
	 	function gensign_val($sotpdata, $appkey)
	 	{
	 		$str = "";
	 		$arr_tmp = array();
	 		$indexof;
	 		
	 		//转为数组  （去掉sign字段）
	 		$arr = explode("&", $sotpdata);
	 		for($i=0; $i< count($arr); $i++) {
	 			$tmp = explode("=", $arr[$i]);
	 			
	 			$indexof = strpos($arr[$i], "=");
	 			$tmp[1] = substr($arr[$i], $indexof+1);
	 			
	 			if ($tmp[0] == 'sign')
	 				continue;
	 			$arr_tmp[$tmp[0]] = $tmp[1];		
	 		} 
	 		
	 		//排序
	 		ksort($arr_tmp);
	 		
	 		//重新组成字符串
	 		foreach ($arr_tmp as $key => $val) {
    			$str .= "$key=$val&";
	 		} 
	 		$str .= "appKey=".$appkey;
	 		
	 		$str = stripslashes($str);
 
	 		//hash值
	 		$res = sha1($str);
	 		
	 		return $res;
	 	}	

//***********************************************************************	
	
}
	
?>
